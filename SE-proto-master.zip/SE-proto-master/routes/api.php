<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/users/bcs','UserController@bestCollaborative');
Route::get('/users/bcs','UserController@bestCollaborative');
Route::apiResource('/users','UserController');

Route::get('/pages/bought/{id}','PageController@bought');
Route::get('/pages/create/{id}','PageController@created');
Route::get('/pages/search','PageController@search');
Route::get('/pages/search/advanedFilter','PageController@advancedFilter');
Route::apiResource('/pages','PageController');

Route::get('/pages/{idPagina}/contents/scarica/{id}','ContentsController@scarica');
Route::get('/pages/{idPagina}/contents/acquista/{id}','ContentsController@acquista');
Route::put('/pages/{idPagina}/contents/segnala/{id}','ContentsController@segnala');
Route::put('/pages/{idPagina}/contents/vota/{id}','ContentsController@vota');
Route::apiResource('/pages/{idPagina}/contents','contentsController');

Route::post('/universities','UniversitiesController@store');
Route::post('/universities/courses','UniversitiesController@addCourse');

Route::post('/moderators','ModeratorsController@store');
Route::delete('/moderators/{id}','ModeratorsController@destroy');
Route::put('/moderators/{id}','ModeratorsController@update');




