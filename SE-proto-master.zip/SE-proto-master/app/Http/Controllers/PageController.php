<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return 'pagine';
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
//CREA PAGINA
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

//VISUALIZZA PAGINA
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
//AGGIORNA PAGINA
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
//CANCELLA PAGINA
    public function destroy($id)
    {
        //
    }

//PAGINE AQUISTATE
    public function bought($id)
    {
        return 'pagine comprate';

    }
//PAGINE CREATE

    public function created($id)
    {

        return 'pagine comprate';

    }

//RICERCA

    public function search(Request $request)
    {

        return 'risultati ricerca';

    }
//FILRAGGIO AVANZATO

    public function advancedFilter(Request $request)
    {

        return 'risultati filtraggio avanzata';

    }




}
