<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ModeratorsController extends Controller
{
//CREA MODERATORE
    public function store(Request $request)
    {
        //
    }
//PROMUOVI A MODERATORE
    public function update(Request $request, $id)
    {
        //
    }

//CANCELLA MODERATORE
    public function destroy($id)
    {
        //
    }
}
