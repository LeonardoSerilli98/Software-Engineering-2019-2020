<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UniversitiesController extends Controller
{

//AGGIUNGI UNIVERSITÀ
    public function store(Request $request)
    {
        return 'università aggiunta';

    }
//AGGIUNGI CORSO
    public function addCourse(Request $corso)
    {
        return 'corso aggiunto';
    }
}
