<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class contentsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

//CARICA APPUNTO
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
//VISUALIZZA ANTEPRIMA
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

//AGGIORNA APPUNTO

    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
//CANCELLA APPUNTO
    public function destroy($id)
    {
        //
    }

//ACQUISTA APPUNTO
    public function acquista($id)
    {
        return 'acquistato con successo';
    }
//SCARICA APPUNTO
    public function scarica($id)
    {
        //
    }
//SEGNALA APPUNTO
    public function segnala($id)
    {
        //
    }
//VOTA APPUNTO
    public function vota($id)
    {
        //
    }

}
